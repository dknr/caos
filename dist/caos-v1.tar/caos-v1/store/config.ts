export type CaosConfig = {
  path: string;
};