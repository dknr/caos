export default {
  localhost: 'http://localhost:31923'
}